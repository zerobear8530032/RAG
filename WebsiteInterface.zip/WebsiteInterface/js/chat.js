/**
 * Chat Page JavaScript
 * Handles chat functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendBtn = document.getElementById('send-btn');
    const chatItems = document.querySelectorAll('.chat-item');
    
    // Function to add a new message
    function addMessage(text, isSent = true) {
        if (!text.trim()) return;
        
        const currentTime = new Date();
        const hours = currentTime.getHours();
        const minutes = currentTime.getMinutes();
        const timeString = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
        
        const messageElement = document.createElement('div');
        messageElement.className = isSent ? 'message sent' : 'message received';
        
        let messageHTML = '';
        
        if (!isSent) {
            messageHTML += `
                <div class="message-avatar">
                    <i class="fas fa-user-circle"></i>
                </div>
            `;
        }
        
        messageHTML += `
            <div class="message-content">
                <div class="message-text">
                    <p>${text}</p>
                </div>
                <div class="message-time">${timeString}</div>
            </div>
        `;
        
        messageElement.innerHTML = messageHTML;
        chatMessages.appendChild(messageElement);
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Send message on button click
    if (sendBtn && messageInput) {
        sendBtn.addEventListener('click', () => {
            const message = messageInput.value;
            addMessage(message);
            messageInput.value = '';
            
            // Simulate a response after a short delay
            setTimeout(() => {
                const responses = [
                    "I'll look into that for you.",
                    "Thanks for the update!",
                    "Can you provide more details?",
                    "Let's discuss this in our next meeting.",
                    "Great progress!",
                    "I'll share this with the team."
                ];
                const randomResponse = responses[Math.floor(Math.random() * responses.length)];
                addMessage(randomResponse, false);
            }, 1000 + Math.random() * 2000);
        });
        
        // Send message on Enter key
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendBtn.click();
            }
        });
    }
    
    // Chat item click
    chatItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove active class from all items
            chatItems.forEach(i => i.classList.remove('active'));
            
            // Add active class to clicked item
            item.classList.add('active');
            
            // Update chat header with contact info
            const contactName = item.querySelector('h4').textContent;
            const contactStatus = 'Online'; // This would be dynamic in a real app
            
            const chatHeader = document.querySelector('.chat-contact');
            if (chatHeader) {
                chatHeader.innerHTML = `
                    <div class="contact-avatar">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <div class="contact-info">
                        <h3>${contactName}</h3>
                        <p>${contactStatus}</p>
                    </div>
                `;
            }
            
            // Clear chat messages (would load conversation history in a real app)
            chatMessages.innerHTML = `
                <div class="message-date">
                    <span>Today</span>
                </div>
            `;
            
            // Add a welcome message
            setTimeout(() => {
                addMessage(`Hi there! How can I help you today?`, false);
            }, 300);
        });
    });
    
    // Mobile chat functionality
    // In a mobile view, we need to be able to toggle between the chat list and the chat view
    const chatSidebar = document.querySelector('.chat-sidebar');
    const chatMain = document.querySelector('.chat-main');
    
    if (window.innerWidth <= 768) {
        // Add a back button to the chat header
        const chatHeader = document.querySelector('.chat-header');
        const backBtn = document.createElement('button');
        backBtn.className = 'action-btn back-btn';
        backBtn.innerHTML = '<i class="fas fa-arrow-left"></i>';
        backBtn.style.marginRight = '10px';
        
        chatHeader.querySelector('.chat-contact').insertBefore(backBtn, chatHeader.querySelector('.chat-contact').firstChild);
        
        // Show chat list by default on mobile
        if (chatSidebar) chatSidebar.style.display = 'flex';
        if (chatMain) chatMain.style.display = 'none';
        
        // Show chat when clicking on a chat item
        chatItems.forEach(item => {
            item.addEventListener('click', () => {
                if (chatSidebar) chatSidebar.style.display = 'none';
                if (chatMain) chatMain.style.display = 'flex';
            });
        });
        
        // Show chat list when clicking back button
        backBtn.addEventListener('click', () => {
            if (chatSidebar) chatSidebar.style.display = 'flex';
            if (chatMain) chatMain.style.display = 'none';
        });
    }
    
    // Handle window resize
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            // Reset display for desktop view
            if (chatSidebar) chatSidebar.style.display = 'flex';
            if (chatMain) chatMain.style.display = 'flex';
        } else {
            // Check if we have an active chat
            const activeChat = document.querySelector('.chat-item.active');
            if (activeChat && chatMain.style.display !== 'none') {
                // Keep showing the chat view
                if (chatSidebar) chatSidebar.style.display = 'none';
                if (chatMain) chatMain.style.display = 'flex';
            } else {
                // Show chat list by default
                if (chatSidebar) chatSidebar.style.display = 'flex';
                if (chatMain) chatMain.style.display = 'none';
            }
        }
    });
});
